import Landing from './landing/Landing';
import Services from './services/Services';
import About from './about/About';
import Team from './team/Team';
// import Contact from './contact/Contact.js';


// export {Landing, Contact, Resources, Services, Team};
export {Landing, Services, About, Team};