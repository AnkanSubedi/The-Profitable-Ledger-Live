import { useEffect } from "react"
import ContactForm from "./ContactForm"

const Contact = useEffect(document.title = "Contact | TPL");

export default Contact